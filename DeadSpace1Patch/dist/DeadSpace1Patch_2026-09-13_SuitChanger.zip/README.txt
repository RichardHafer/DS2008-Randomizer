Dead Space 1 Patch / Randomizer (build 2026-09-13)

Install: unpack everything into the Dead Space game folder (next to "Dead Space.exe").
  plugins\DeadSpace1Patch.asi        the patch (loaded by dinput8.dll)
  dinput8.dll                        ASI loader (keep it, or use your own that loads plugins\)
  DeadSpace1Patch.ini                settings, exactly the ones this build was tested with
  DeadSpace1Progression*.tsv         progression manifest (only used when enabled in the ini)
  DeadSpace1Patch_SpawnCatalog.tsv   spawn catalog
  ds1_randomizer_assets\             enemy pool streams

New in this build:
  Suit changer: F9 opens the menu, TAB switches to the cheats page, the row
  "Suit: < level N >" picks a suit level with LEFT/RIGHT, ENTER applies it;
  "Suit: random" picks another one at random. Works in a loaded level.
  Ini switch: SuitChanger=1.
  "Remove all weapons" only writes diagnostics to the log for now.
